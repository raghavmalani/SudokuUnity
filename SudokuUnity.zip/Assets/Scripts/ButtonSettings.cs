﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class ButtonSettings : MonoBehaviour
{
    public void ButtonClick(string setting)
    {
        if(setting == "easy")
        {
            Settings.difficulty = Settings.Difficulties.EASY;
        }
        if (setting == "medium")
        {
            Settings.difficulty = Settings.Difficulties.MEDIUM;
        }
        if (setting == "hard")
        {
            Settings.difficulty = Settings.Difficulties.HARD;
        }
        if (setting == "legend")
        {
            Settings.difficulty = Settings.Difficulties.LEGEND;
        }

        SceneManager.LoadScene("SScene1");
    }

    public void Replay()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void BackToMenu()
    {
        SceneManager.LoadScene("GameScene");
    }

    /*public void ReturnMenu()
    {
        SceneManager.LoadScene("SScene1");
    }*/

    public void StartGame()
    {
        SceneManager.LoadScene("GameScene");
    }



    
}
