﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Security.Cryptography;
using UnityEngine;
using UnityEngine.UI;

public class NumberField : MonoBehaviour
{
    Boardd boarder;
    int x1;
    int y1;
    int value;
    string identifier;
    public Text number;

    public void SetValues(int _x1, int _y1, int _value, string _identifier, Boardd _boarder)
    {
        x1 = _x1;
        y1 = _y1;
        value = _value;
        identifier = _identifier;
        boarder = _boarder;
        number.text = (value != 0) ? value.ToString():  "";
        
        if (value != 0)
        {
            GetComponentInParent<Button>().interactable = false;

        } else
        {
            number.color = Color.blue;
            
        }
        
    }

    public void ButtonClick()
    {
        InputField.instance.ActivateInputField(this);
    }

    public void RecieveInput(int newValue)
    {
        value = newValue;
        number.text = (value != 0)? value.ToString() : "";
        //Update Riddle
        boarder.SetInputInRiddleGrid(x1, y1, value);
    }

    public int GetX()
    {
        return x1;
    }

    public int GetY()
    {
        return y1;
    }

    public void SetHint(int _value)
    {
        value = _value;
        number.text = value.ToString();
        number.color = Color.red;
        GetComponentInParent<Button>().interactable = false;
    }
}
