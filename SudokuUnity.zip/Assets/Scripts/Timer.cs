﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    //public float timeElapsed = 10;
    //public float timeRemaining = 10;
    //public bool timerIsRunning = false;
    public Text timerText;
    private float startTime;
    private bool finnished = false;
    
    // Start is called before the first frame update
    private void Start()
    {
        startTime = Time.time;

    }
    // Update is called once per frame

    void Update()
    {
        
        float t = Time.time - startTime;
        string minutes = Mathf.FloorToInt(t / 60).ToString();
        string seconds = Mathf.FloorToInt(t % 60).ToString();
        timerText.text = string.Format("{0:00}:{1:00}",minutes, seconds);
    }

    public void Finish()
    {
        finnished = true;
        timerText.color = Color.yellow;
    }

}
