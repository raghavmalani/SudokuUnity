﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Settings 
{
    public enum Difficulties
    {
        DEBUG,
        EASY,
        MEDIUM,
        HARD,
        LEGEND
    }

    public static Difficulties difficulty;
}
