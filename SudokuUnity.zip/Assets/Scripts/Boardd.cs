﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Threading;
using UnityEngine;

public class Boardd : MonoBehaviour
{

    int[,] solvedGrid = new int[9, 9];
    string s;
    int[,] riddleGrid = new int[9, 9];

    public Transform A1, A2, A3, B1, B2, B3, C1, C2, C3;
    public GameObject buttonPrefab;

    List<NumberField> fieldList = new List<NumberField>();

    public enum Difficulties
    {
        DEBUG,
        EASY,
        MEDIUM,
        HARD,
        LEGEND
    }

    public GameObject winPanel;
 
    

    public Difficulties difficulty;
    private int maxHints;


    void Start()
    {
        winPanel.SetActive(false);
        
        difficulty = (Boardd.Difficulties)Settings.difficulty;


        FillGridBase(ref solvedGrid);
        SolveGrid(ref solvedGrid);
        CreateRiddleGrid(ref solvedGrid, ref riddleGrid);

        CreateButtons();
        //difficulty = (Boardd.Difficulties)Settings.difficulty;

        //InitGrid(ref solvedGrid);
        // DebugGrid(ref solvedGrid);
        //ShuffleGrid(ref solvedGrid, 5);
        //CreateRiddleGrid();
        //CreateButtons();
    }

    void InitGrid(ref int[,] grid)
    {
        for (int i = 0; i < 9; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                grid[i, j] = (i * 3 + i / 3 + j) % 9 + 1;
            }
        }
    }

    void DebugGrid(ref int[,] grid)
    {
        s = "";
        int sep = 0;
        for (int i = 0; i < 9; i++)
        {
            s += "|";
            for (int j = 0; j < 9; j++)
            {
                s += grid[i, j].ToString();
                sep = j % 3;
                if (sep == 2)
                {
                    s += "|";
                }
            }
            s += "\n";
        }
        print(s);
    }

    void ShuffleGrid(ref int[,] grid, int shuffleAmount)
    {
        for (int i = 0; i < shuffleAmount; i++)
        {
            int value1 = UnityEngine.Random.Range(1, 10);
            int value2 = UnityEngine.Random.Range(1, 10);
            //Mix 2 cells
            MixTwoGridCells(ref grid, value1, value2);
        }
        //DebugGrid(ref grid);
    }

    void MixTwoGridCells(ref int[,] grid, int value1, int value2)
    {
        int x1 = 0;
        int x2 = 0;
        int y1 = 0;
        int y2 = 0;

        for (int i = 0; i < 9; i += 3)
        {
            for (int k = 0; k < 9; k += 3)
            {
                for (int j = 0; j < 3; j++)
                {
                    for (int l = 0; l < 3; l++)
                    {
                        if (grid[i + j, k + l] == value1)
                        {
                            x1 = i + j;
                            y1 = k + l;
                        }

                        if (grid[i + j, k + l] == value2)
                        {
                            x2 = i + j;
                            y2 = k + l;
                        }
                    }
                }
                grid[x1, y1] = value2;
                grid[x2, y2] = value1;
            }
        }
    }

    void CreateRiddleGrid()
    {
        for (int i = 0; i < 9; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                riddleGrid[i, j] = solvedGrid[i, j];
            }
        }

        //Set Difficulty
        SetDifficulty();

        //Erase from Riddle Grid
        for (int i = 0; i <= peicesToErase; i++)
        {
            int x1 = UnityEngine.Random.Range(0, 9);
            int y1 = UnityEngine.Random.Range(0, 9);

            while (riddleGrid[x1, y1] == 0)
            {
                x1 = UnityEngine.Random.Range(0, 9);
                y1 = UnityEngine.Random.Range(0, 9);
            }
            //Once we find with no 0
            riddleGrid[x1, y1] = 0;
        }
        //DebugGrid(ref riddleGrid);
    }

    void CreateButtons()
    {
        for (int i = 0; i < 9; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                GameObject newButton = Instantiate(buttonPrefab);

                NumberField numField = newButton.GetComponent<NumberField>();
                numField.SetValues(i, j, riddleGrid[i, j], i + "," + j, this);
                newButton.name = i + "," + j;

                if(riddleGrid[i,j] == 0)
                {
                    fieldList.Add(numField);
                }


                //Parent the button
                //A1
                if (i < 3 && j < 3)
                {
                    newButton.transform.SetParent(A1, false);
                }
                //A2
                if (i < 3 && j > 2 && j < 6)
                {
                    newButton.transform.SetParent(A2, false);
                }
                //A3
                if (i < 3 && j > 5)
                {
                    newButton.transform.SetParent(A3, false);
                }
                //B1
                if (i > 2 && i < 6 && j < 3)
                {
                    newButton.transform.SetParent(B1, false);
                }
                //B2
                if (i > 2 && i < 6 && j > 2 && j < 6)
                {
                    newButton.transform.SetParent(B2, false);
                }
                //B3
                if (i > 2 && i < 6 && j > 5)
                {
                    newButton.transform.SetParent(B3, false);
                }
                //C1
                if (i > 5 && j < 3)
                {
                    newButton.transform.SetParent(C1, false);
                }
                //C2
                if (i > 5 && j > 2 && j < 6)
                {
                    newButton.transform.SetParent(C2, false);
                }
                //C3
                if (i > 5 && j > 5)
                {
                    newButton.transform.SetParent(C3, false);
                }
            }
        }
    }

    public void SetInputInRiddleGrid(int x, int y, int value)
    {
        riddleGrid[x, y] = value;
    }

    void SetDifficulty()
    {
        switch (difficulty)
        {
            case Difficulties.DEBUG:
                peicesToErase = 5;
                maxHints = 1;
                break;
            case Difficulties.EASY:
                peicesToErase = 40;
                maxHints = 2;
                break;
            case Difficulties.MEDIUM:
                peicesToErase = 45;
                maxHints = 2;
                break;
            case Difficulties.HARD:
                peicesToErase = 50;
                maxHints = 3;
                break;
            case Difficulties.LEGEND:
                peicesToErase = 60;
                maxHints = 3;
                break;
        }
    }

    

    public void CheckComplete()
    {
        if (CheckIfWon())
        {
            print("You won!");
            winPanel.SetActive(true);
        }
        else
        {
            print("Try Again!");
        }
    }

    bool CheckIfWon()
    {
        for (int i = 0; i < 9; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                if (riddleGrid[i, j] != solvedGrid[i, j])
                {
                    return false;
                }
            }
        }
        return true;
    }

    public void ShowHint()
    {
        if(fieldList.Count > 0 && maxHints > 0)
        {
            int randIndex = UnityEngine.Random.Range(0, fieldList.Count);

            maxHints--;
            riddleGrid[fieldList[randIndex].GetX(), fieldList[randIndex].GetY()] = solvedGrid[fieldList[randIndex].GetX(), fieldList[randIndex].GetY()];
            fieldList[randIndex].SetHint(riddleGrid[fieldList[randIndex].GetX(), fieldList[randIndex].GetY()]);
            fieldList.RemoveAt(randIndex);
        } else
        {
            //print("No Hints Left");
        }
    }

    //----------------ALL Checks----------------------------//
    bool ColumnContainsNumber(int y, int value, ref int[,] grid)
    {
        for (int x = 0; x < 9; x++)
        {
            if(grid[x,y] == value)
            {
                return true;
            }
        }
        return false;
    }

    bool RowContainsNumber(int x, int value, ref int[,] grid)
    {
        for (int y = 0; y < 9; y++)
        {
            if (grid[x, y] == value)
            {
                return true;
            }
        }
        return false;
    }

    bool BlockContainsNumber(int x, int y, int value, ref int[,] grid)
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if(grid[x - (x % 3) + i, y - (y % 3) + j] == value)
                {
                    return true;
                }
            }
        }
        return false;
    }

    bool CheckAll(int x, int y, int value, ref int[,] grid)
    {
        if (ColumnContainsNumber(y, value, ref grid)) {
            return false;
        }
        if (RowContainsNumber(x, value, ref grid)) {
            return false;
        }
        if (BlockContainsNumber(x , y,value, ref grid)) {
            return false;
        }
            
        return true;
    }

    bool IsValidCheck(ref int[,] grid)
    {
        for (int i = 0; i < 9; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                if(grid[i,j] == 0)
                {
                    return false;
                }
            }
        }
        return true;
    }

    //------------GENERATE GRID-----------------------------//

    void FillGridBase(ref int[,] grid)
    {
        List<int> rowValues = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        List<int> columnValues = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

        int value = rowValues[UnityEngine.Random.Range(0, rowValues.Count)];

        grid[0, 0] = value;
        rowValues.Remove(value);
        columnValues.Remove(value);

        for (int i = 1; i < 9; i++)
        {
            value = rowValues[UnityEngine.Random.Range(0, rowValues.Count)];
            grid[i, 0] = value;
            rowValues.Remove(value);
        }

        for (int i = 1; i < 9; i++)
        {
            value = columnValues[UnityEngine.Random.Range(0, columnValues.Count)];
            if (i < 3)
            {
                while (BlockContainsNumber(0, 0, value, ref grid))
                {
                    value = columnValues[UnityEngine.Random.Range(0, columnValues.Count)];
                }
            }
            grid[0, i] = value;
            columnValues.Remove(value);
        }
        DebugGrid(ref grid);
    }       

    bool SolveGrid(ref int[,] grid)
    {
        DebugGrid(ref grid);
        if(IsValidCheck(ref grid))
        {
            return true;
        }
        int x = 0;
        int y = 0;

        for (int i = 0; i < 9; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                if(grid[i,j] == 0)
                {
                    x = i;
                    y = j;
                    break;
                }
            }
        }

        List<int> possibilities = new List<int>();
        possibilities = GetAllPossibilities(x, y, ref grid);

        for (int p = 0; p < possibilities.Count; p++)
        {
            grid[x, y] = possibilities[p];
            if (SolveGrid(ref grid))
            {
                return true;
            }
            else
            {
                grid[x, y] = 0;
            }
        }

        return false;
    }

    List<int> GetAllPossibilities(int x, int y, ref int[,] grid)
    {
        List<int> possibilities = new List<int>();
        for (int val = 0; val <= 9; val++)
        {
            if(CheckAll(x,y,val,ref grid))
            {
                possibilities.Add(val);
            }
        }
        return possibilities;
    }

    void CreateRiddleGrid(ref int[,] sGrid, ref int[,] rGrid)
    {
        System.Array.Copy(sGrid, rGrid, sGrid.Length);

        //Set Difficulty
        SetDifficulty();

        //Erase from Riddle Grid
        for (int i = 0; i <= peicesToErase; i++)
        {
            int x1 = UnityEngine.Random.Range(0, 9);
            int y1 = UnityEngine.Random.Range(0, 9);

            while (riddleGrid[x1, y1] == 0)
            {
                x1 = UnityEngine.Random.Range(0, 9);
                y1 = UnityEngine.Random.Range(0, 9);
            }
            //Once we find with no 0
            rGrid[x1, y1] = 0;
            
        }
        DebugGrid(ref riddleGrid);
    }
}
